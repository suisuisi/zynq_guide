-= SD card boot image =-

Platform: te0726_m_sdsoc
Application: C:/Users/Adam/ZynqBerry_Workspace/hello_world_bare/SDDebug/_sds/swstubs/hello_world_bare.elf

1. Copy the contents of this directory to an SD card (without Boot.bin)
2. Configure Flash with boot.bin
4. Insert SD card and turn board on
