/****************************************Copyright (c)****************************************************
**                            Guangzhou ZLGMCU Development Co., LTD
**
**                                 http://www.zlgmcu.com
**
**--------------File Info---------------------------------------------------------------------------------
** File name:           main.c
** Last modified Date:  2013-04-28
** Last Version:        V1.0
** Descriptions:        The main() function example template
**
**--------------------------------------------------------------------------------------------------------
** Created by:          liweifeng
** Created date:        2013-04-28
** Version:             V1.00
** Descriptions:        
**--------------------------------------------------------------------------------------------------------*/

#ifndef __CC_H__ 
#define __CC_H__ 

#include <stdint.h>
#include <stdio.h>
#include "lwipopts.h"
#include "xil_printf.h"

/* Types based on stdint.h */
typedef uint8_t            u8_t; 
typedef int8_t             s8_t; 
typedef uint16_t           u16_t; 
typedef int16_t            s16_t; 
typedef uint32_t           u32_t; 
typedef int32_t            s32_t; 
typedef uintptr_t          mem_ptr_t; 

/* Define (sn)printf formatters for these lwIP types */
#define U16_F "hu"
#define S16_F "hd"
#define X16_F "hx"
#define U32_F "lu"
#define S32_F "ld"
#define X32_F "lx"
#define SZT_F "uz"

/* ARM/LPC17xx is little endian only */
//#define BYTE_ORDER LITTLE_ENDIAN

/* Use LWIP error codes */
//#define LWIP_PROVIDE_ERRNO

#if defined(__arm__) && defined(__ARMCC_VERSION) 
	/* Keil uVision4 tools */
    #define PACK_STRUCT_BEGIN __packed
    #define PACK_STRUCT_STRUCT
    #define PACK_STRUCT_END
    #define PACK_STRUCT_FIELD(fld) fld
	#define ALIGNED(n)  __align(n)
#elif defined (__IAR_SYSTEMS_ICC__) 
	/* IAR Embedded Workbench tools */
    #define PACK_STRUCT_BEGIN __packed
    #define PACK_STRUCT_STRUCT
    #define PACK_STRUCT_END
    #define PACK_STRUCT_FIELD(fld) fld
//    #define PACK_STRUCT_USE_INCLUDES
	#define ALIGNEDX(x)      _Pragma(#x)
	#define ALIGNEDXX(x)     ALIGNEDX(data_alignment=x)
	#define ALIGNED(x)       ALIGNEDXX(x)
#else 
	/* GCC tools (CodeSourcery) */
    #define PACK_STRUCT_BEGIN
    #define PACK_STRUCT_STRUCT __attribute__ ((__packed__))
    #define PACK_STRUCT_END
    #define PACK_STRUCT_FIELD(fld) fld
	#define ALIGNED(n)  __attribute__((aligned (n)))
//	#define ALIGNED(n)  __align(n)
#endif 

/* Used with IP headers only */
//#define LWIP_CHKSUM_ALGORITHM 1


#ifdef LWIP_DEBUG
/**
 * @brief	Displays an error message on assertion
 * @param	msg		: Error message to display
 * @param	line	: Line number in file with error
 * @param	file	: Filename with error
 * @return	Nothing
 * @note	This function will display an error message on an assertion
 * to the debug output.
 */
void assert_printf(char *msg, int line, char *file);

/* Plaform specific diagnostic output */
#define LWIP_PLATFORM_ASSERT(x)
#define LWIP_PLATFORM_DIAG(x) do { xil_printf x; } while(0)

#else   

/**
 * @brief	LWIP optimized assertion loop (no LWIP_DEBUG)
 * @return	DoesnNothing, function doesn't return
 */
void assert_loop(void);
#define LWIP_PLATFORM_DIAG(msg) { ; }
#define LWIP_PLATFORM_ASSERT(flag) { assert_loop(); }
#endif 

#endif
