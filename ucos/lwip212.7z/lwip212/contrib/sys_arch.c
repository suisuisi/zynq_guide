/****************************************Copyright (c)****************************************************
**                            Guangzhou ZLGMCU Development Co., LTD
**
**                                 http://www.zlgmcu.com
**
**--------------File Info---------------------------------------------------------------------------------
** File name:           main.c
** Last modified Date:  2013-04-28
** Last Version:        V1.0
** Descriptions:        
**
**--------------------------------------------------------------------------------------------------------
** Created by:          liweifeng
** Created date:        2013-04-28
** Version:             V1.00
** Descriptions:        
**--------------------------------------------------------------------------------------------------------*/

#include "lwip/debug.h"
#include "lwip/def.h"
#include "lwip/sys.h"
#include "lwip/mem.h"

#include <os_cfg.h>
#include <os_cpu.h>
#include <ucos_ii.h>

#include <stdio.h>
#include <string.h>
#include <xtime_l.h>

 #if NO_SYS==0
/* ------------------------ System architecture includes ----------------------------- */
#include "sys_arch.h"

/* ------------------------ lwIP includes --------------------------------- */
#include "lwip/opt.h"
#include "lwip/stats.h"

ST_LWIP_MBOX     __staLwIPMBoxs[MBOX_NB];
PST_LWIP_MBOX           pstCurFreeMBox;

unsigned long long *Xtime_Global;

//* LwIP�߳�ʹ�õĶ�ջ,����ֻ������TCPIP�Ķ�ջ��ʹ��PPP��SLIP��Ҫ�ض���
//OS_STK T_LWIP_THREAD_STK[T_LWIP_THREAD_MAX_NB][T_LWIP_THREAD_STKSIZE];
OS_STK TCPIP_THREAD_STK[TCPIP_THREAD_STACKSIZE];


const void * const pvNullPointer = (mem_ptr_t*)0xffffffff;

/*---------------------------------------------------------------------------*
 * Routine:  sys_mbox_new
 *---------------------------------------------------------------------------*
 * Description:
 *      Creates a new mailbox
 * Inputs:
 *      int size                -- Size of elements in the mailbox
 * Outputs:
 *      sys_mbox_t              -- Handle to new mailbox
 *---------------------------------------------------------------------------*/
err_t sys_mbox_new( sys_mbox_t *pxMailBox, int iSize )
{
	OS_CPU_SR cpu_sr;

	PST_LWIP_MBOX	__pstMBox = SYS_MBOX_NULL;
    err_t xReturn = ERR_MEM;

	OS_ENTER_CRITICAL();
	{
		if(pstCurFreeMBox != NULL)
		{
			__pstMBox = pstCurFreeMBox;
			pstCurFreeMBox = __pstMBox->pstNext;
		}
	}
    
    *pxMailBox = __pstMBox;
    
	OS_EXIT_CRITICAL();
    
    if( *pxMailBox != NULL ) {
        xReturn = ERR_OK;
	}
	
	return xReturn;
}

void sys_mbox_free( sys_mbox_t *pxMailBox )
{
	OS_CPU_SR cpu_sr;

	//* Ϊ�˷�ֹ����������������������һ������
	OSQFlush((*pxMailBox)->hMBox);

	OS_ENTER_CRITICAL();
	{
		(*pxMailBox)->pstNext = pstCurFreeMBox;
		pstCurFreeMBox        = (*pxMailBox);
	}
	OS_EXIT_CRITICAL();
}

void sys_mbox_post( sys_mbox_t *pxMailBox, void *pxMessageToPost )
{
    u8_t ubErr, i=0;
    
//    ubErr = ubErr;
    
    if( pxMessageToPost == NULL ) {
       pxMessageToPost = (void*)&pvNullPointer; 
    }
    
    while((i<10) && ((ubErr = OSQPost( (*pxMailBox)->hMBox, pxMessageToPost)) != OS_NO_ERR)) {
    	i++;
    	OSTimeDly(5);
    }
}

err_t sys_mbox_trypost( sys_mbox_t *pxMailBox, void *pxMessageToPost )
{
    u8_t ubErr;
    
//    ubErr =ubErr;
    
    if(pxMessageToPost == NULL ) {
       pxMessageToPost = (void*)&pvNullPointer; 
    }
    
    if((ubErr = OSQPost( (*pxMailBox)->hMBox, pxMessageToPost)) != OS_NO_ERR)
        return ERR_MEM;

    return ERR_OK;
}


//�ȴ������е���Ϣ
u32_t sys_arch_mbox_fetch( sys_mbox_t *pxMailBox, void **ppvBuffer, u32_t timeout )
{    
    u8_t	ucErr;
    u32_t	ucos_timeout, timeout_new;
    void	*temp;
    
    if(timeout != 0)
    {
    	ucos_timeout = (timeout * OS_TICKS_PER_SEC)/1000; //convert to timetick
    	
    	if(ucos_timeout < 1)
            ucos_timeout = 1;
    	else if(ucos_timeout > 65535)	//ucOS only support u16_t timeout
            ucos_timeout = 65535;
    }
    else ucos_timeout = 0;
    
    timeout = OSTimeGet();
    
    temp = OSQPend( (*pxMailBox)->hMBox, (u16_t)ucos_timeout, &ucErr );
    
    if(ppvBuffer != NULL)
    {
    	if( temp == (void*)&pvNullPointer )
            *ppvBuffer = NULL;
    	else
            *ppvBuffer = temp;
    }   
    
    if ( ucErr == OS_TIMEOUT ) 
        timeout = SYS_ARCH_TIMEOUT;
    else
    {
    	LWIP_ASSERT( "OSQPend ", ucErr == OS_NO_ERR );
    	
        timeout_new = OSTimeGet();
        if (timeout_new>timeout) timeout_new = timeout_new - timeout;
        else timeout_new = 0xffffffff - timeout + timeout_new;
        
        timeout = timeout_new * 1000 / OS_TICKS_PER_SEC + 1; //convert to milisecond
    }

	return timeout; 
}

u32_t sys_arch_mbox_tryfetch( sys_mbox_t *pxMailBox, void **ppvBuffer )
{
    void   *pvDummy;
     u8_t	ucErr;
    void	*tmp;
    
	if( ppvBuffer== NULL )
	{
		ppvBuffer = &pvDummy;
	}
    
    //tmp = OSQPend( (*pxMailBox)->hMBox, 0, &ucErr );
    tmp = OSQAccept((*pxMailBox)->hMBox, &ucErr );
    if(ppvBuffer != NULL)
    {
    	if( tmp == (void*)&pvNullPointer )
            *ppvBuffer = NULL;
    	else
            *ppvBuffer = tmp;
    } 

	if(tmp != (void *)0)
		return ERR_OK;
	else
		return SYS_MBOX_EMPTY;
}


err_t sys_sem_new( sys_sem_t *pSem, u8_t ucCount )
{
    *pSem = OSSemCreate((u16_t)ucCount);
    if(*pSem==NULL) return ERR_MEM;
    LWIP_ASSERT("OSSemCreate ",pSem != NULL );
    return ERR_OK;
}

u32_t sys_arch_sem_wait( sys_sem_t *pxSemaphore, u32_t timeout )
{
    u8_t ucErr;
    u32_t ucos_timeout, timeout_new;
    
    // timeout in ms
    if(	timeout != 0)
    {
        ucos_timeout = (timeout * OS_TICKS_PER_SEC) / 1000; // convert to timetick
        if(ucos_timeout < 1)
            ucos_timeout = 1;
        else if(ucos_timeout > 65536) // uC/OS only support u16_t pend
            ucos_timeout = 65535; 
    }
    else ucos_timeout = 0;
    
    timeout = OSTimeGet();//(OS_EVENT *) 
    
    OSSemPend (*pxSemaphore,(u16_t)ucos_timeout, (u8_t *)&ucErr);
    
    if(ucErr == OS_TIMEOUT)
        timeout = SYS_ARCH_TIMEOUT;	// only when timeout!
    else
    {    
    	//LWIP_ASSERT( "OSSemPend ", ucErr == OS_NO_ERR );
        //for pbuf_free, may be called from an ISR
        
        timeout_new = OSTimeGet(); 
        if (timeout_new>=timeout) timeout_new = timeout_new - timeout;
        else timeout_new = 0xffffffff - timeout + timeout_new;
        
        timeout = (timeout_new * 1000 / OS_TICKS_PER_SEC + 1); //convert to milisecond 
    }
    
    return timeout;
}

err_t sys_mutex_new( sys_mutex_t *pxMutex ) 
{
    *pxMutex = OSSemCreate(1);
    LWIP_ASSERT("OSMutCreate ",pxMutex != NULL );
    return ERR_OK;
}

void sys_mutex_lock( sys_mutex_t *pxMutex )
{
    u8_t ucErr;
	OSSemPend (*pxMutex, 0, (u8_t *)&ucErr);
}


void sys_mutex_unlock(sys_mutex_t *pxMutex )
{
	OSSemPost(*pxMutex);
}

void sys_mutex_free( sys_mutex_t *pxMutex )
{
    u8_t     ucErr;
    (void)OSSemDel(*pxMutex, OS_DEL_ALWAYS, &ucErr );
    LWIP_ASSERT( "OSSemDel ", ucErr == OS_NO_ERR ); 
}

void sys_sem_signal( sys_sem_t *pxSemaphore )
{
    OSSemPost(*pxSemaphore);
}

void sys_sem_free( sys_sem_t *pxSemaphore )
{
    u8_t    ucErr;
    (void)OSSemDel(*pxSemaphore, OS_DEL_ALWAYS, &ucErr );
    LWIP_ASSERT( "OSSemDel ", ucErr == OS_NO_ERR ); 
}

sys_thread_t sys_thread_new( const char *pcName, void( *thread )( void *pvParameters ), void *arg, int iStackSize, int prio )
{
	OS_CPU_SR cpu_sr;
	INT8U ERR;
    iStackSize =iStackSize;

    OS_ENTER_CRITICAL();
    ERR = OSTaskCreate(thread, arg, &TCPIP_THREAD_STK[iStackSize-1], prio);
    OS_EXIT_CRITICAL();

    if(OS_NO_ERR == ERR)
        return prio;
    else
    {
    	xil_printf("Create Task err_code:%d", ERR);
        return ERR;
    }
}

sys_prot_t sys_arch_protect( void )
{
	return ( sys_prot_t ) OS_CPU_SR_Save();
}

void sys_arch_unprotect( sys_prot_t xValue )
{
	OS_CPU_SR_Restore((OS_CPU_SR)xValue);
}

void sys_assert( const char *pcMessage )
{
	(void) pcMessage;

	for (;;)
	{
	}
}

u32_t sys_now()
{
	u32_t ucos_time, lwip_time;
	ucos_time=OSTimeGet();
	lwip_time=(ucos_time*1000/OS_TICKS_PER_SEC+1);
	return lwip_time;
}

void sys_init(void)
{
    INT8U i;
	
	//* �Ȱ�������0
	memset(__staLwIPMBoxs, 0, sizeof(__staLwIPMBoxs));
	
	//* ��������������
	for(i=0; i<(MBOX_NB-1); i++)
	{
		//* �������еĸ���Ա������һ��
		__staLwIPMBoxs[i].pstNext = &__staLwIPMBoxs[i+1];
				
		//* �������䣬ϵͳ���뱣֤�����ܹ�˳��������������ִ������ǳ���BUG��Ӧ���ڵ��Խ׶��ų�
		__staLwIPMBoxs[i].hMBox = OSQCreate(__staLwIPMBoxs[i].pvaMsgs, MBOX_SIZE);
	}
	
	//* ���������������һ��Ԫ�أ�����û�н���������
	__staLwIPMBoxs[MBOX_NB-1].hMBox = OSQCreate(__staLwIPMBoxs[MBOX_NB-1].pvaMsgs, MBOX_SIZE);
	
	//* ���������׵�ַ
	pstCurFreeMBox = __staLwIPMBoxs;
}

#endif

/*-----------------------------------------------------------------------------------*/
