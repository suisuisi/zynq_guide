#ifndef _LWIPENTER_H_
#define _LWIPENTER_H_

#include <stdio.h>
#include "xparameters.h"
#include "netif/xadapter.h"
#include "platform_config.h"
#include "xil_printf.h"
#include "lwip/sockets.h"
#include "lwipopts.h"
#include "lwip/init.h"

#include  "ucos_ii.h"

#define LwipEnter_STACKSIZE 512


void LwipEnter_thread(void *p_arg);
void print_echo_app_header();
void echo_application_thread();
void print_echo_app_header();
void process_echo_request(void *p);
void network_thread(void *p);



#endif
